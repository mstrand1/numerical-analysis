from find_roots import FindRoot

from interpolation import Interpolation

from lin_systems import LinSys

from num_methods import NumMethods
